# Ansible Collection - zjleblanc.reporting

Collection of roles for generating html reports
